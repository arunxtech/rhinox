    <?php $__env->startSection('content'); ?>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Countries</h4><a class="linkClass" href="<?php echo e(route('addCountry')); ?>">Add new country</a>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-hover table-striped">
                                    <thead>
                                        <tr><th>ID</th>
                                            <th>Name</th>
                                            <th>Action</th>
                                        </tr></thead>
                                    <tbody>
                                        <?php $__currentLoopData = $fetchCountry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($value['id']); ?></td>
                                                <td><?php echo e($value['name']); ?></td>
                                                <td><a href="<?php echo e(route('editCountry', ['slug' => $value['slug']])); ?>">edit</a> |
                                                    <a href="<?php echo e(route('deleteCountry', ['slug' => $value['slug']])); ?>" onclick="if (!confirm('are you sure want to delete country?')) return false;" >delete</a></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('Theme::layouts.baseLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rhinox.local\app\Modules/Country/Views/index.blade.php ENDPATH**/ ?>