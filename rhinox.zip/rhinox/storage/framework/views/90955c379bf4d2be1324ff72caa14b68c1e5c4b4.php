<?php $__env->startSection("content"); ?>

<?php 

?>


<!------------- slider ---------------->

<div id="carouselSlider" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="http://codingmaker.com/demo/wordpress-custom-theme/wp-content/uploads/2020/04/750x300-no-img.png" alt="Slider Image">
    </div> 
  
	<div class="carousel-item">
	  <img  class="d-block w-100"  src="http://codingmaker.com/demo/wordpress-custom-theme/wp-content/uploads/2020/04/750x300-no-img.png" alt="Slider Image">
	  <div class="carousel-caption d-none d-md-block">
		<h5>Third slide label</h5>
		<p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
	  </div>
	</div>
  
  </div>
  <a class="carousel-control-prev" href="#carouselSlider" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselSlider" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<!------------- slider ---------------->


<div class="container mt-3"> 
 
<div class="row mt-3">
<div class="col-md-8">
<div class="container_body">
<div class="box_mid_css">
<h2 class="mb-3">Latest News</h2>
<div class="row">


<?php
$news_count = 0;
foreach($news as $news_v){
 $news_count++;	 
 
 if($news_v->image==""){
	$news_v->image='no-img.png';
 }
 ?>

<div class="col-md-4">
<div class="box_img_news">
<figure ><a href="<?php echo e(url('/')); ?>/News/<?php echo e($news_v->slug); ?>"><img title="<?php echo e($news_v->image_title); ?>" alt="<?php echo e($news_v->alt_tag); ?>" src="<?php echo e(url('/')); ?>/images/news/<?php echo e($news_v->image); ?>">
</a>
</figure>
<div><h2><a  href="<?php echo e(url('/')); ?>/News/<?php echo e($news_v->slug); ?>" title="<?php echo e($news_v->title); ?>">
	<p><?php echo e($news_v->title); ?></p></a>
</h2>
</div>
</div>
</div>
 

<?php } ?>  

</div>

<div class="row">
	<div class="col-md-12">
		<?php echo e($news->links()); ?>

	</div>
</div>


</div>



</div>
</div>


<!-- sidebar --> 
<?php echo $__env->make('frontend.layouts.sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- sidebar -->

</div>

   
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("frontend.layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rhinox.local\resources\views/frontend/index.blade.php ENDPATH**/ ?>