<div class="col-md-4 " > 

<!-------------------->

<div class="container_body">
<div class="box_right">
<div class="box_right_title"><h3>Sidebar ads</h3> 
</div>

<div class="mt-3">
<img title="Ad Banner" alt="Ad Banner" src="<?php echo e(url('/')); ?>/assets/img/ads.png">
</div>  
</div> 
</div>

<!-------------------->


<!-------------------->


<div class="container_body mt-3">
<div class="box_right">
<div class="box_right_title"><h3>Sidebar content</h3> 
</div>

<div class="mt-3">
 <p>
 You can put anything you want inside of these side widgets. <br><br>
 <b>This is dummy content.</b> 
 <br>
 (
 Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
 )
 
 </p>
</div> 

</div>
	<div class="btn-wrapper">
	<a class="btn" href="">View More</a>
	</div>
</div>

<!-------------------->


</div><?php /**PATH C:\xampp\htdocs\rhinox.local\resources\views/frontend/layouts/sidebar/sidebar.blade.php ENDPATH**/ ?>