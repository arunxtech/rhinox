<?php
    $currentRouteName = strlen(Route::currentRouteName()) ? Route::currentRouteName() : null;
?>

<ul class="nav">
	<li class="<?php echo e(($currentRouteName == 'dashboard') ? 'active' : ''); ?>">
		<a href="<?php echo e(route('dashboard')); ?>">
			<i class="pe-7s-graph"></i>
			<p>Dashboard</p>
		</a>
	</li>
	<li class="<?php echo e(in_array($currentRouteName, ['countries', 'addCountry', 'editCountry']) ? 'active' : ''); ?>">
		<a href="<?php echo e(route('countries')); ?>">
			<p>Country</p>
		</a>
	</li>
	        
        <li class="<?php echo e(in_array($currentRouteName, ['blog', 'addBlog', 'editBlog']) ? 'active' : ''); ?>">
           
		<a href="<?php echo e(route('blog')); ?>">
			<p>Blog</p>
		</a>
	</li>
        
	<li class="<?php echo e(in_array($currentRouteName, ['news', 'addNews', 'editNews']) ? 'active' : ''); ?>">
		<a href="<?php echo e(route('news')); ?>">
			<p>News</p>
		</a>
	</li>
	
	
	<li class="<?php echo e(($currentRouteName == 'logout') ? 'active' : ''); ?>">
		<a href="<?php echo e(route('logout')); ?>">
			<p>Logout</p>
		</a>
	</li>

</ul><?php /**PATH C:\xampp\htdocs\rhinox.local\app\Modules/Theme/Views/layouts/menu.blade.php ENDPATH**/ ?>