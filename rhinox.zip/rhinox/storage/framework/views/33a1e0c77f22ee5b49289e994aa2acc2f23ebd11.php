<footer class="footer">
	<div class="container-fluid">
		<p class="copyright pull-right">
			&copy; <?php echo e(date('Y')); ?> </p>
	</div>
</footer><?php /**PATH C:\xampp\htdocs\rhinox.local\app\Modules/Theme/Views/layouts/footer.blade.php ENDPATH**/ ?>