<!doctype html>
<html lang="en" itemscope itemtype="http://schema.org/WebPage">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="shortcut icon" href="" />     
	<title>Codingmaker - laravel sample project</title>
	<meta name="description" content="">
	<link rel="stylesheet" href="<?php echo e(url('assets/css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(url('assets/css/style.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(url('assets/font-awesome-4.7.0/css/font-awesome.min.css')); ?>">  
 </head>
  <body>
  <header>
   <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
   <div class="container">
  <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
	<img  alt=""  src="<?php echo e(url('assets/img/logo.png')); ?>">
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(url('/')); ?>">Home</a>
      </li> 
	  <li class="nav-item ">
        <a class="nav-link" href=""> About Us</a>
      </li> 
	  
	  <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="<?php echo e(url('Cricket-Team')); ?>" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Main menu
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown"> 
          <a class="dropdown-item" href="#">Sub menu</a>
		  <a class="dropdown-item" href="#">Sub menu</a>
		  <a class="dropdown-item" href="#">Sub menu</a>
		  <a class="dropdown-item" href="#">Sub menu</a>
		  <a class="dropdown-item" href="#">Sub menu</a>
        </div>
      </li>
	  
	   
	  <li class="nav-item ">
        <a class="nav-link" href="<?php echo e(url('/')); ?>/News">News <span class="sr-only">(current)</span></a>
      </li>
	  
	  <li class="nav-item ">
        <a class="nav-link" href="#">Contact us </a>
      </li>
    </ul>
    
  </div>
  <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2 search_input" type="search" placeholder="Search" aria-label="Search">
      <button class="search btn btn-outline-success my-2 my-sm-0" type="button"><i class="fa fa-search" aria-hidden="true"></i></button>
    </form>
  </div>
</nav>
</header> 

<?php echo $__env->yieldContent('content'); ?>

<footer itemscope itemtype="http://schema.org/WPFooter">
 <div class="container">
 <div class="row">
 
	<div class="col-md-3">
		<h4>ABOUT US</h4>
		<ul> 
		<li><p class="mb-0" >PHONE:  9700000000 </p> </li>
		<li><p class="mb-0" >EMAIL:  manojb99.ccna@gmail.com </p> </li>
		<li><p class="mb-0" >ADDRESS: test address</p></li>
	</div>

  
	<div class="col-md-3">
		<h4>Follow us on</h4>
		<ul>
		<li><a href=""><i class="fa fa-facebook" aria-hidden="true"></i> Facebook</a></li>
		<li><a href=""><i class="fa fa-twitter" aria-hidden="true"></i> Twitter</a></li>
		<li><a href=""><i class="fa fa-youtube-play" aria-hidden="true"></i> Youtube</a></li>
		<li><a href=""><i class="fa fa-pinterest-p" aria-hidden="true"></i> Pinterest</a></li>
		</ul>
	</div>
  
  
	<div class="col-md-3">
		<h4>Information</h4>
		<ul>
		 <li><a href="">Page 1</a></li>
		 <li><a href="">Page 2</a></li>
		 <li><a href="">Page 3</a></li>
		 <li><a href="">Page 4</a></li>
		</ul>
	</div>
  
	<div class="col-md-3">
		<h4>Information</h4>
		<ul>
		 <li><a href="">Page 1</a></li>
		 <li><a href="">Page 2</a></li>
		 <li><a href="">Page 3</a></li>
		 <li><a href="">Page 4</a></li>
		</ul>
	</div>
   
	
 </div>
 </div>
 </footer>
   
   
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="<?php echo e(url('assets/js/jquery-3.4.1.js')); ?>"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="<?php echo e(url('assets/js/bootstrap.min.js')); ?>"></script>
     <script src="<?php echo e(url('assets/js/custom.js')); ?>"></script>
 <script>

$("button.search").click(function(){
  $("input.search_input").toggle();
});

  </script>
  <?php echo $__env->yieldPushContent('custom-scripts'); ?>
  <style>
.b-bo-al-bv a { display: inline-block;}
.plers_box ul { justify-content: flex-end;}
.plers_box ul li a.active{color:rgb(228, 77, 11) !important;}
   </style>
  </body>
</html><?php /**PATH D:\xampp\htdocs\project\codingmaker\demo\laravel-sample-project\resources\views/frontend/layouts/master.blade.php ENDPATH**/ ?>