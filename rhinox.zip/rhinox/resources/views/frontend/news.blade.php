@extends("frontend.layouts.master")
@section("content")

@php 

@endphp
 
 

<div class="container mt-3">

<div class="breadcrumb">
<ul>
	<li>
		<a href="{{ url('/') }}" ><span>Home</span></a> » 
	</li>
	<li>
		<a class="active" href="#" ><span>News</span></a>
	</li>
</ul>
</div>			

<div class="row mt-3">
<div class="col-md-8 ">
<div class="container_body">
<div class="box_mid_css">
<h2 class="mb-3">Latest News</h2>
<div class="row">


<?php
$news_count = 0;
foreach($news as $news_v){
 $news_count++;	 
 
 if($news_v->image==""){
	$news_v->image='no-img.png';
 }
 ?>

<div class="col-md-4">
<div class="box_img_news">
<figure ><a href="{{ url('/') }}/News/{{ $news_v->slug }}"><img title="{{ $news_v->image_title }}" alt="{{ $news_v->alt_tag }}" src="{{ url('/') }}/images/news/{{ $news_v->image }}">
</a>
</figure>
<div><h2><a  href="{{ url('/') }}/News/{{ $news_v->slug }}" title="{{ $news_v->title }}">
	<p>{{ $news_v->title }}</p></a>
</h2>
</div>
</div>
</div>
 

<?php } ?>  

</div>

<div class="row">
	<div class="col-md-12">
		{{ $news->links() }}
	</div>
</div>


</div>



</div>
</div>


<!-- sidebar --> 
@include('frontend.layouts.sidebar.sidebar')
<!-- sidebar -->

</div>

</div> 

 
@endsection