@extends("frontend.layouts.master")
@section("content")

@php 

@endphp
 
<!--------------------------------> 

<div class="container mt-3">
   <div class="breadcrumb">
      <ul>
         <li>
            <a href="{{ url('/') }}" ><span>Home</span></a> » 
         </li>
         <li>
            <a href="{{ url('/News') }}" ><span>News</span></a> » 
            
         </li>
         <li>
            <a class="active" href="#" ><span>{{ $newsDetials->title }}</span></a>           
         </li>
      </ul>
   </div>
   

   
   <div>
      <div class="container_body"> 
         <div class="box_mid_css">
            <h1 class="mb-3">{{ $newsDetials->title }}</h1>
            <div class="web_formet">
				<span class="ng-binding">{{ date('D, M d, Y, h:i A', strtotime($newsDetials->posted)) }}</span>
            </div>
         </div>
      </div>
      <div class="row mt-3">
         <div class="col-md-8">
            <div class="container_body">
               <div class="box_mid_css">
                  <section class="news">  
                     <img class="news_img" alt="{{ $newsDetials->alt_tag }}" title="{{ $newsDetials->image_title }}" src="{{ url('/') }}/images/news/{{ $newsDetials->image }}"> 
                     <div class="news_img_cptn">{{ $newsDetials->image_title }}</div>
                  </section>
                  <section class="news_article" >
                     <?php echo html_entity_decode($newsDetials->description); ?>
                  </section>
                  <div class="news_tags">Tags</div>
                  <div class="news_tags">
				     <?php
					 $newstags = explode(",",$newsDetials->tags);
					 ?>
					 @foreach ($newstags as  $value) 
					 
					 <?php 
					 $valuey = str_replace(" ","-",$value);
					 ?>
                     <a href="#" title="{{$value}} "> {{$value}} </a>
                      @endforeach
                  </div>
				  
                  <div class="box_mid_css">
                     <h2 class="mb-3" itemprop="headline">Releted News 
                        <a class="collapse_icon" data-toggle="collapse" href="#collapseExample">
                        <i class="fa fa-chevron-down" aria-hidden="true"></i>
                        </a>
                     </h2>
                     <div class="collapse_none" id="collapseExample">
                        <div class="row">
						
													   
							<?php
							$news_count = 0;
							foreach($news as $news_v){
							 $news_count++;	
							  if($news_v->image==""){
								$news_v->image='no-img.png';
							  }
							 ?>
							<div class="col-md-4">
								<div class="box_img_news">
								<figure ><a href="{{ url('/') }}/News/{{ $news_v->slug }}"><img title="{{ $news_v->image_title }}" alt="{{ $news_v->alt_tag }}" src="{{ url('/') }}/images/news/{{ $news_v->image }}">
								</a>
								</figure>
								<div><h2><a  href="{{ url('/') }}/News/{{ $news_v->slug }}" title="{{ $news_v->title }}">
									<p>{{ $news_v->title }}</p></a>
								</h2>
								</div>
								</div>
								</div>
							<?php } ?> 
						   
                           
						
						</div>
                        <div class="text-right">
                           <a href="{{ url('/News') }}" class="btn">View More</a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
		 
		 
         <!-- sidebar -->
         @include('frontend.layouts.sidebar.sidebar')
         <!-- sidebar -->
		 
      </div>
   </div>
</div>

 
<!-------------------------------->
 
@endsection