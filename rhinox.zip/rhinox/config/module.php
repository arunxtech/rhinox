<?php

return [
    'modules' => [
        'Theme',
        'Home',
        'Login',
        'Dashboard',
        'Country',
        'Team',
        'Series',
        'SeriesSquad',
        'Match',
        'MatchTeams',
        'MatchSquad',
        'Gallery',
        'Player',
        'News',
        'IccRanking'
    ]
];
